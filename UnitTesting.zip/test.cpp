// Uncomment the next line to use precompiled headers
#include "pch.h"
#include <exception>
#include <iostream>
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO-01: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0

    // Assert true if the collection is empty - Richard
    ASSERT_TRUE(collection->empty());

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?

    // If an entry is added to a collection the size must be 1 -Richard
    ASSERT_EQ(collection->size(), 1);
}

// TODO-02: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    // If five entries are added to a collection the size must be 5 -Richard
    ASSERT_EQ(collection->size(), 5);
}

// TODO-03: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsMaxSizeGreaterThanOrEqualToSize) 
{
    // Empty - Verify max size is greater than or equal to zero on empty collection -Richard
    ASSERT_GE(collection->max_size(), 0);

    // 1 Entry - Verify max size is greater than or equal to 1 on a collection of 1 entries -Richard
    add_entries(1);

    ASSERT_GE(collection->max_size(), 1);

    // 5 Entries - Verify max size is greater than or equal to 5 on a collection of 5 entries -Richard
    add_entries(5);

    ASSERT_GE(collection->max_size(), 5);

    // 10 Entries - Verify max size is greater than or equal to 10 on a collection of 10 entries -Richard
    add_entries(10);

    ASSERT_GE(collection->max_size(), 10);
}

// TODO-04: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, IsCapacityGreaterThanOrEqualToSize)
{
    // Empty - Verify max size is greater than or equal to zero on empty collection -Richard
    ASSERT_GE(collection->capacity(), 0);

    // 1 Entry - Verify max size is greater than or equal to 1 on a collection of 1 entries -Richard
    add_entries(1);

    ASSERT_GE(collection->capacity(), 1);

    // 5 Entries - Verify max size is greater than or equal to 5 on a collection of 5 entries -Richard
    add_entries(5);

    ASSERT_GE(collection->capacity(), 5);

    // 10 Entries - Verify max size is greater than or equal to 10 on a collection of 10 entries -Richard
    add_entries(10);

    ASSERT_GE(collection->capacity(), 10);
}

// TODO-05: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, CanIncreasSizeOfCollection)
{
    // Verify collection size is zero - Richard
    ASSERT_EQ(collection->size(), 0);

    // Resize collection to three, verify size of collection - Richard
    collection->resize(3);

    ASSERT_EQ(collection->size(), 3);
}

// TODO-06: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, CanDecreasSizeOfCollection)
{
    // Add three entries to the collection -Richard
    add_entries(3);

    // Verify the size of the collection is three
    ASSERT_EQ(collection->size(), 3);   

    // Resize the collection to two and verify size is two
    collection->resize(2);
    
    ASSERT_EQ(collection->size(), 2);
}

// TODO-07: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, CanDecreasSizeOfCollectionToZero)
{
    // Add three entries to the collection -Richard
    add_entries(3);

    // Verify the size of the collection is three
    ASSERT_EQ(collection->size(), 3);

    // Resize the collection to zero and verify size is zero
    collection->resize(0);

    ASSERT_EQ(collection->size(), 0);
}

// TODO-08: Create a test to verify clear erases the collection
TEST_F(CollectionTest, CanEraseCollection)
{
    // Add three entries to the collection -Richard
    add_entries(3);

    // Verify the size of the collection is three
    ASSERT_EQ(collection->size(), 3);

    // Erase the collection, verify size is zero, verify collection is zero - Richard
    collection->clear();

    EXPECT_EQ(collection->size(), 0);

    // Assert true if the collection is empty - Richard
    ASSERT_TRUE(collection->empty());
}

// TODO-09: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, CanEraseRangeOfCollection)
{
    // Add three entries to the collection -Richard
    add_entries(12);

    // Verify the size of the collection is three
    ASSERT_EQ(collection->size(), 12);

    // Erase the collection, verify size is zero, verify collection is zero - Richard
    collection->erase(collection->begin(), collection->begin() + 12);

    EXPECT_EQ(collection->size(), 0);

    // Assert true if the collection is empty - Richard
    ASSERT_TRUE(collection->empty());
}

// TODO-10: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, CanIncreaseReserveNotCapacity)
{
    // Add three entries to a collection
    add_entries(3);

    // Check the size of the collection equals three
    ASSERT_EQ(collection->size(), 3);

    // Use reserve to increase the capacity by 2, confirm capacity equals five
    collection->reserve(5);

    ASSERT_EQ(collection->capacity(), 5);

    // Confirm size is three
    ASSERT_EQ(collection->size(), 3);
}

// TODO-11: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, IsOutOfRangeTrapped)
{
    try
    {
        // Add three entries to a collection
        add_entries(3);

        // Check the size of the collection equals three, reference an element out of range, verify exception
        ASSERT_EQ(collection->size(), 3);

        std::cout << collection->at(5);
    }
    catch (std::exception& e)
    {
        bool caught = true;

        ASSERT_TRUE(caught);
    }    
}


// TODO-12: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// Verify Shrink-To-fit reduces capcity to size
TEST_F(CollectionTest, CanShrinkToFit)
{
    // Add three entries to a collection
    add_entries(3);

    // Check the size of the collection equals three
    ASSERT_EQ(collection->size(), 3);

    // Use reserve to increase the capacity by 2, confirm capacity equals five
    collection->reserve(5);

    ASSERT_EQ(collection->capacity(), 5);

    // Confirm size is three
    ASSERT_EQ(collection->size(), 3);

    // Shrink the capacity verify now is 3
    collection->shrink_to_fit();

    ASSERT_EQ(collection->capacity(), 3);
}

// TODO-13: Verify referencing an entry in a increased capacity produces an exception - NEGATIVE TEST
TEST_F(CollectionTest, IsExceptionWhenInCapacityOutofRange)
{
    try
    {
        // Add three entries to a collection
        add_entries(3);

        // Check the size of the collection equals three
        ASSERT_EQ(collection->size(), 3);

        // Use reserve to increase the capacity by 2, confirm capacity equals five
        collection->reserve(5);

        ASSERT_EQ(collection->capacity(), 5);

        // Confirm size is three
        ASSERT_EQ(collection->size(), 3);

        std::cout << collection->at(4) << std::endl;
    }
    catch (std::exception& e)
    {
        bool caught = true;

        ASSERT_TRUE(caught);
    }
}
